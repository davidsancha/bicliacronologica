
import { BookOverview, BibleMapEntry, VideoEntry, WorshipEntry, BiblicalEra } from './types';

export const BIBLICAL_TIMELINE: BiblicalEra[] = [
  { id: 'creation', dispensation: 'Inocência', title: 'Criação', description: 'O Início de Tudo', books: ['Gn 1', 'Gn 2', 'Gn 3', 'Gn 4', 'Gn 5', 'Gn 6', 'Gn 7', 'Gn 8', 'Gn 9', 'Gn 10', 'Gn 11'], color: 'bg-emerald-500', icon: '🌱', year: '4000 a.C.' },
  { id: 'patriarchs', dispensation: 'Promessa', title: 'Patriarcas', description: 'Abraão, Isaque e Jacó', books: ['Gn 12', 'Gn 25', 'Gn 37', 'Jó'], color: 'bg-amber-500', icon: '⛺', year: '2100 a.C.' },
  { id: 'exodus', dispensation: 'Lei', title: 'Êxodo', description: 'Libertação do Egito', books: ['Êx', 'Lv', 'Nm', 'Dt'], color: 'bg-blue-500', icon: '🌊', year: '1446 a.C.' },
  { id: 'conquest', dispensation: 'Lei', title: 'Conquista', description: 'Possuindo Canaã', books: ['Js'], color: 'bg-red-500', icon: '⚔️', year: '1400 a.C.' },
  { id: 'judges', dispensation: 'Lei', title: 'Juízes', description: 'Ciclos de Israel', books: ['Jz', 'Rt'], color: 'bg-purple-500', icon: '⚖️', year: '1375 a.C.' },
  { id: 'united_kingdom', dispensation: 'Lei', title: 'Reino Unido', description: 'Saul, Davi e Salomão', books: ['1Sm', '2Sm', '1Rs 1', '1Rs 2', '1Rs 3', '1Rs 4', '1Rs 5', '1Rs 6', '1Rs 7', '1Rs 8', '1Rs 9', '1Rs 10', '1Rs 11', '1Cr', 'Sl', 'Pv', 'Ec', 'Ct'], color: 'bg-yellow-500', icon: '👑', year: '1050 a.C.' },
  { id: 'divided_kingdom', dispensation: 'Lei', title: 'Reino Dividido', description: 'Israel vs Judá', books: ['1Rs 12', '2Rs', '2Cr', 'Is', 'Jr', 'Ez', 'Os', 'Jl', 'Am', 'Ob', 'Mq', 'Na', 'Hc', 'Sf'], color: 'bg-orange-500', icon: '💔', year: '930 a.C.' },
  { id: 'exile', dispensation: 'Lei', title: 'Exílio', description: 'Cativeiro Babilônico', books: ['Lm', 'Dn', 'Ez'], color: 'bg-slate-500', icon: '⛓️', year: '586 a.C.' },
  { id: 'return', dispensation: 'Lei', title: 'Retorno', description: 'Reconstrução', books: ['Ed', 'Ne', 'Et', 'Ag', 'Zc', 'Ml'], color: 'bg-cyan-500', icon: '🏗️', year: '538 a.C.' },
  { id: 'silence', dispensation: 'Lei', title: 'Silêncio', description: '400 Anos de Silêncio', books: [], color: 'bg-indigo-300', icon: '🤫', year: '400 a.C.' },
  { id: 'christ', dispensation: 'Graça', title: 'Cristo', description: 'Vida de Jesus', books: ['Mt', 'Mc', 'Lc', 'Jo'], color: 'bg-sky-400', icon: '✝️', year: '4 a.C.' },
  { id: 'church', dispensation: 'Graça', title: 'Igreja', description: 'Expansão do Evangelho', books: ['At', 'Rm', '1Co', '2Co', 'Gl', 'Ef', 'Fp', 'Cl', '1Ts', '2Ts', '1Tm', '2Tm', 'Tt', 'Fm', 'Hb', 'Tg', '1Pe', '2Pe', '1Jo', '2Jo', '3Jo', 'Jd'], color: 'bg-rose-500', icon: '🕊️', year: '33 d.C.' },
  { id: 'consummation', dispensation: 'Reino', title: 'Consumação', description: 'Glorificação', books: ['Ap'], color: 'bg-violet-600', icon: '🏙️', year: 'Futuro' }
];

export const KINGS_DATABASE = {
  united: [
    { name: 'Saul', books: ['1Sm 10', '1Sm 31'] },
    { name: 'Davi', books: ['2Sm', '1Cr'] },
    { name: 'Salomão', books: ['1Rs 1', '1Rs 11', '2Cr 1', '2Cr 9'] }
  ],
  divided: [
    { north: 'Jeroboão I', south: 'Roboão', ref: '1Rs 12' },
    { north: 'Acabe', south: 'Josafá', ref: '1Rs 16' },
    { north: 'Oséias', south: 'Ezequias', ref: '2Rs 18' },
    { north: '(Cativeiro)', south: 'Josias', ref: '2Rs 22' }
  ]
};

export const BIBLE_MAP: Record<string, BibleMapEntry> = {
  "Gn": { name: "Gênesis", theme: "Criação e Início" },
  "Êx": { name: "Êxodo", theme: "Libertação e Milagres" },
  "Lv": { name: "Levítico", theme: "Santidade e Adoração" },
  "Nm": { name: "Números", theme: "Deserto e Provisão" },
  "Dt": { name: "Deuteronômio", theme: "Obediência e Lei" },
  "Js": { name: "Josué", theme: "Conquista" },
  "Jz": { name: "Juízes", theme: "Ciclos e Juízes" },
  "Rt": { name: "Rute", theme: "Lealdade" },
  "1Sm": { name: "1 Samuel", theme: "Reino de Israel" },
  "2Sm": { name: "2 Samuel", theme: "Reinado de Davi" },
  "1Rs": { name: "1 Reis", theme: "Reis e Profetas" },
  "2Rs": { name: "2 Reis", theme: "Reis e Exílio" },
  "1Cr": { name: "1 Crônicas", theme: "Genealogias" },
  "2Cr": { name: "2 Crônicas", theme: "História de Judá" },
  "Ed": { name: "Esdras", theme: "Retorno e Reconstrução" },
  "Ne": { name: "Neemias", theme: "Muros de Jerusalém" },
  "Et": { name: "Ester", theme: "Providência Divina" },
  "Jó": { name: "Jó", theme: "Provação e Fidelidade" },
  "Sl": { name: "Salmos", theme: "Adoração e Confiança" },
  "Pv": { name: "Provérbios", theme: "Sabedoria" },
  "Ec": { name: "Eclesiastes", theme: "Sentido da Vida" },
  "Ct": { name: "Cânticos", theme: "Amor Divino" },
  "Is": { name: "Isaías", theme: "Profecia e Messias" },
  "Jr": { name: "Jeremias", theme: "O Profeta Chorão" },
  "Lm": { name: "Lamentações", theme: "Lamento" },
  "Ez": { name: "Ezequiel", theme: "Visões de Deus" },
  "Dn": { name: "Daniel", theme: "Soberania de Deus" },
  "Os": { name: "Oseias", theme: "Amor Fiel" },
  "Jl": { name: "Joel", theme: "Dia do Senhor" },
  "Am": { name: "Amós", theme: "Justiça Social" },
  "Ob": { name: "Obadias", theme: "Julgamento de Edom" },
  "Jn": { name: "Jonas", theme: "Misericórdia de Deus" },
  "Mq": { name: "Miqueias", theme: "Justiça e Misericórdia" },
  "Na": { name: "Naum", theme: "Julgamento de Nínive" },
  "Hc": { name: "Habacuque", theme: "Fé na Adversidade" },
  "Sf": { name: "Sofonias", theme: "Dia da Ira" },
  "Ag": { name: "Ageu", theme: "Reconstrução do Templo" },
  "Zc": { name: "Zacarias", theme: "Visões Messiânicas" },
  "Ml": { name: "Malaquias", theme: "Mensageiro de Deus" },
  "Mt": { name: "Mateus", theme: "Reino de Deus" },
  "Mc": { name: "Marcos", theme: "Servo Sofredor" },
  "Lc": { name: "Lucas", theme: "Filho do Homem" },
  "Jo": { name: "João", theme: "Amor de Deus" },
  "At": { name: "Atos", theme: "Igreja Primitiva" },
  "Rm": { name: "Romanos", theme: "Graça e Salvação" },
  "1Co": { name: "1 Coríntios", theme: "Problemas na Igreja" },
  "2Co": { name: "2 Coríntios", theme: "Ministério Apostólico" },
  "Gl": { name: "Gálatas", theme: "Liberdade Cristã" },
  "Ef": { name: "Efésios", theme: "Unidade da Igreja" },
  "Fp": { name: "Filipenses", theme: "Alegria" },
  "Cl": { name: "Colossenses", theme: "Supremacia de Cristo" },
  "1Ts": { name: "1 Tessalonicenses", theme: "Volta de Cristo" },
  "2Ts": { name: "2 Tessalonicenses", theme: "Dia do Senhor" },
  "1Tm": { name: "1 Timóteo", theme: "Liderança" },
  "2Tm": { name: "2 Timóteo", theme: "Fidelidade" },
  "Tt": { name: "Tito", theme: "Vida Cristã" },
  "Fm": { name: "Filemom", theme: "Perdão" },
  "Hb": { name: "Hebreus", theme: "Superioridade de Cristo" },
  "Tg": { name: "Tiago", theme: "Fé e Obras" },
  "1Pe": { name: "1 Pedro", theme: "Esperança Viva" },
  "2Pe": { name: "2 Pedro", theme: "Crescimento Espiritual" },
  "1Jo": { name: "1 João", theme: "Comunhão" },
  "2Jo": { name: "2 João", theme: "Verdade e Amor" },
  "3Jo": { name: "3 João", theme: "Hospitalidade" },
  "Jd": { name: "Judas", theme: "Falsos Mestres" },
  "Ap": { name: "Apocalipse", theme: "Vitória Final" }
];

export const BOOK_OVERVIEWS: Record<string, BookOverview> = {
  "Gn": { title: "Gênesis", desc: "O livro das origens.", context: "Escrito por Moisés (c. 1440 a.C.), narra a criação, a queda do homem, o dilúvio e a escolha da família de Abraão para abençoar as nações.", theme: "Soberania Divina e a Aliança da Promessa.", key: "No princípio, criou Deus os céus e a terra. (1:1)", christ: "A semente da mulher (3:15) e o descendente de Abraão.", videoId: "CV72TjLBMkY" },
  "Êx": { title: "Êxodo", desc: "A redenção de Israel.", context: "Narra a libertação da escravidão no Egito, a entrega da Lei no Sinai e a construção do Tabernáculo.", theme: "Redenção pelo sangue e Habitação de Deus com o homem.", key: "Eu sou o Senhor, teu Deus, que te tirei da terra do Egito. (20:2)", christ: "O Cordeiro Pascal (1 Co 5:7) e o Mediador da nova aliança.", videoId: "jH_aojNJM3E" },
  "Lv": { title: "Levítico", desc: "O manual de santidade e adoração.", context: "Estabelece as leis sacrificiais e de pureza para que um Deus Santo possa habitar no meio de um povo pecador.", theme: "Santidade: 'Sede santos, porque eu sou santo'.", key: "Fala a toda a congregação... Sereis santos, porque eu, o Senhor vosso Deus, sou santo. (19:2)", christ: "O Sumo Sacerdote perfeito e o sacrifício definitivo que remove o pecado.", videoId: "W3JqR-k0gMQ" },
  "Nm": { title: "Números", desc: "A jornada no deserto.", context: "A peregrinação de 40 anos no deserto devido à incredulidade e a preparação da nova geração.", theme: "A severidade e a bondade de Deus; a fidelidade de Deus apesar da infidelidade humana.", key: "O Senhor te abençoe e te guarde... (6:24)", christ: "A Rocha ferida (1 Co 10:4) e a Serpente de Bronze (Jo 3:14).", videoId: "tp5W8Yk5E8w" },
  "Dt": { title: "Deuteronômio", desc: "A segunda lei.", context: "Discursos de despedida de Moisés às planícies de Moabe, reafirmando a aliança antes da entrada na terra.", theme: "Amor e obediência: Amar a Deus de todo o coração.", key: "Ouve, Israel, o Senhor nosso Deus é o único Senhor. (6:4)", christ: "O Profeta semelhante a Moisés (Dt 18:15).", videoId: "q54D2tD-k3Y" },
  "Js": { title: "Josué", desc: "A conquista da terra.", context: "A liderança de Josué na conquista de Canaã e a divisão da terra entre as tribos.", theme: "Deus cumpre Suas promessas de terra e descanso.", key: "Não to mandei eu? Sê forte e corajoso... (1:9)", christ: "O Capitão do exército do Senhor (Js 5:14) que nos dá descanso.", videoId: "JqOqJlFF_eU" },
  "Jz": { title: "Juízes", desc: "Ciclos de apostasia.", context: "Período caótico antes da monarquia, marcado por ciclos de pecado, opressão, clamor e livramento.", theme: "O fracasso humano e a necessidade de um Rei justo.", key: "Naqueles dias não havia rei em Israel; cada um fazia o que achava mais reto. (21:25)", christ: "O verdadeiro Juiz e Libertador definitivo.", videoId: "kOYyWK254Q" },
  "Rt": { title: "Rute", desc: "O amor redentor.", context: "Uma história de lealdade e providência divina durante o tempo escuro dos Juízes.", theme: "Redenção e a inclusão dos gentios no plano de Deus.", key: "O teu povo é o meu povo, o teu Deus é o meu Deus. (1:16)", christ: "O nosso Parente Redentor (Boaz prefigura Cristo).", videoId: "0h1eoBeR4Jk" },
  "1Sm": { title: "1 Samuel", desc: "Do teocracia à monarquia.", context: "A transição da liderança de Juízes (Samuel) para Reis (Saul e Davi).", theme: "O Rei segundo o coração de Deus.", key: "O homem vê o exterior, porém o Senhor vê o coração. (16:7)", christ: "O Ungido (Messias) de Deus, prefigurado em Davi.", videoId: "QJOju5Dw0V0" },
  "2Sm": { title: "2 Samuel", desc: "O reinado de Davi.", context: "O estabelecimento do trono de Davi, suas vitórias, seu pecado e as consequências familiares.", theme: "A aliança davídica e a graça de Deus.", key: "A tua casa e o teu reino serão firmados para sempre... (7:16)", christ: "O Filho de Davi que reina para sempre.", videoId: "YvoDeLMqRgg" },
  "Default": { title: "Leitura Bíblica", desc: "Nova porção das Escrituras.", context: "Toda a Escritura é inspirada por Deus.", theme: "Revelação Divina.", key: "Lâmpada para os meus pés.", christ: "Tudo aponta para Ele.", videoId: null }
};

export const READING_PLAN_2026: Record<string, string> = {
  "01/01": "Gn 1–3", "02/01": "Gn 4–6", "03/01": "Gn 7–9", "04/01": "Gn 10–11; Jó 1", "05/01": "Jó 2–4",
  "06/01": "Jó 5–7", "07/01": "Jó 8–10", "08/01": "Jó 11–13", "09/01": "Jó 14–17", "10/01": "Jó 18–21",
  "11/01": "Jó 22–24", "12/01": "Jó 25–27", "13/01": "Jó 28–31", "14/01": "Jó 32–34", "15/01": "Jó 35–37",
  "16/01": "Jó 38–40", "17/01": "Jó 41–42; Gn 12", "18/01": "Gn 13–15", "19/01": "Gn 16–18", "20/01": "Gn 19–21",
  "21/01": "Gn 22–24", "22/01": "Gn 25–26", "23/01": "Gn 27–29", "24/01": "Gn 30–31", "25/01": "Gn 32–34",
  "26/01": "Gn 35–37", "27/01": "Gn 38–40", "28/01": "Gn 41–42", "29/01": "Gn 43–45", "30/01": "Gn 46–50",
  "31/01": "Êx 1–3", "01/02": "Êx 4–6", "02/02": "Êx 7–9", "03/02": "Êx 10–12", "04/02": "Êx 13–15",
  "05/02": "Êx 16–18", "06/02": "Êx 19–21", "07/02": "Êx 22–24", "08/02": "Êx 25–27", "09/02": "Êx 28–30",
  "10/02": "Êx 31–33", "11/02": "Êx 34–36", "12/02": "Êx 37–40", "13/02": "Lv 1–3", "14/02": "Lv 4–6",
  "15/02": "Lv 7–9", "16/02": "Lv 10–12", "17/02": "Lv 13–15", "18/02": "Lv 16–18", "19/02": "Lv 19–21",
  "20/02": "Lv 22–24", "21/02": "Lv 25–27", "22/02": "Nm 1–3", "23/02": "Nm 4–6", "24/02": "Nm 7",
  "25/02": "Nm 8", "26/02": "Nm 9–11", "27/02": "Nm 12–14", "28/02": "Nm 15–17", "01/03": "Nm 18–20",
  "02/03": "Nm 21–22; Sl 90", "03/03": "Nm 23–25", "04/03": "Nm 26–27", "05/03": "Nm 28–30", "06/03": "Nm 31–33",
  "07/03": "Nm 34–36", "08/03": "Dt 1–3", "09/03": "Dt 4–6", "10/03": "Dt 7–9", "11/03": "Dt 10–12",
  "12/03": "Dt 13–15", "13/03": "Dt 16–18", "14/03": "Dt 19–21", "15/03": "Dt 22–24", "16/03": "Dt 25–27",
  "17/03": "Dt 28–30", "18/03": "Dt 31–34", "19/03": "Js 1–3", "20/03": "Js 4–6", "21/03": "Js 7–9",
  "22/03": "Js 10–12", "23/03": "Js 13–15", "24/03": "Js 16–18", "25/03": "Js 19–21", "26/03": "Js 22–24",
  "27/03": "Jz 1–3", "28/03": "Jz 4–6", "29/03": "Jz 7–9", "30/03": "Jz 10–12", "31/03": "Jz 13–15",
  "01/04": "Jz 16–18", "02/04": "Jz 19–21", "03/04": "Rt 1–4", "04/04": "1Sm 1–3", "05/04": "1Sm 4–7",
  "06/04": "1Sm 8–10", "07/04": "1Sm 11–13", "08/04": "1Sm 14–15", "09/04": "1Sm 16–18", "10/04": "1Sm 19–21",
  "11/04": "1Sm 22–24", "12/04": "1Sm 25–27", "13/04": "1Sm 28–31", "14/04": "2Sm 1–4", "15/04": "2Sm 5–8; Sl 133",
  "16/04": "2Sm 9–12; Sl 51", "17/04": "2Sm 13–15; Sl 3", "18/04": "2Sm 16–18; Sl 23", "19/04": "2Sm 19–21; Sl 40",
  "20/04": "2Sm 22; Sl 18", "21/04": "2Sm 23–24", "22/04": "1Cr 1–5", "23/04": "1Cr 6–10", "24/04": "1Cr 11–13",
  "25/04": "1Cr 14–16", "26/04": "1Cr 17–18", "27/04": "1Cr 19–21", "28/04": "1Cr 22–24", "29/04": "1Cr 25–29",
  "30/04": "1Rs 1–4", "01/05": "1Rs 5–7", "02/05": "1Rs 8; Sl 72", "03/05": "1Rs 9–10", "04/05": "1Rs 11; Sl 127",
  "05/05": "Pv 1–4", "06/05": "Pv 5–8", "07/05": "Pv 9–12", "08/05": "Pv 13–16", "09/05": "Pv 17–20",
  "10/05": "Pv 21–24", "11/05": "Pv 25–28", "12/05": "Pv 29–31", "13/05": "Ct 1–8", "14/05": "Ec 1–6",
  "15/05": "Ec 7–12", "16/05": "1Rs 12–14; 2Cr 10–12", "17/05": "1Rs 15; 2Cr 13–14", "18/05": "2Cr 15–16; 1Rs 16",
  "19/05": "1Rs 17–18", "20/05": "1Rs 19–20", "21/05": "1Rs 21–22; 2Cr 17–18", "22/05": "2Rs 1–3; 2Cr 19–20",
  "23/05": "2Rs 4–6", "24/05": "2Rs 7–9", "25/05": "2Rs 10–12; 2Cr 22–24", "26/05": "2Rs 13–14; 2Cr 25",
  "27/05": "Jn 1–4", "28/05": "Am 1–5", "29/05": "Am 6–9", "30/05": "Os 1–7", "31/05": "Os 8–14",
  "01/06": "2Rs 15; 2Cr 26–27", "02/06": "2Rs 16–17", "03/06": "Is 1–5", "04/06": "Is 6–10", "05/06": "Is 11–15",
  "06/06": "Is 16–20", "07/06": "Is 21–25", "08/06": "Is 26–30", "09/06": "Is 31–35", "10/06": "Is 36–39",
  "11/06": "2Rs 18–20", "12/06": "Mq 1–7", "13/06": "2Rs 21; 2Cr 33", "14/06": "Sf 1–3", "15/06": "Na 1–3",
  "16/06": "Hc 1–3", "17/06": "2Rs 22–23; 2Cr 34–35", "18/06": "Jr 1–3", "19/06": "Jr 4–6", "20/06": "Jr 7–9",
  "21/06": "Jr 10–12", "22/06": "Jr 13–15", "23/06": "Jr 16–18", "24/06": "Jr 19–21", "25/06": "Jr 22–24",
  "26/06": "Jr 25–27", "27/06": "Jr 28–30", "28/06": "Jr 31–33", "29/06": "Jr 34–36", "30/06": "Jr 37–39",
  "01/07": "Jr 40–42", "02/07": "Jr 43–45", "03/07": "Jr 46–48", "04/07": "Jr 49–50", "05/07": "Jr 51–52",
  "06/07": "Lm 1–5", "07/07": "Ob 1; Jl 1–3", "08/07": "Ez 1–4", "09/07": "Ez 5–8", "10/07": "Ez 9–12",
  "11/07": "Ez 13–16", "12/07": "Ez 17–20", "13/07": "Ez 21–24", "14/07": "Ez 25–28", "15/07": "Ez 29–32",
  "16/07": "Ez 33–36", "17/07": "Ez 37–39", "18/07": "Ez 40–42", "19/07": "Ez 43–45", "20/07": "Ez 46–48",
  "21/07": "Dn 1–3", "22/07": "Dn 4–6", "23/07": "Dn 7–9", "24/07": "Dn 10–12", "25/07": "Ed 1–3",
  "26/07": "Ed 4–6", "27/07": "Ag 1–2", "28/07": "Zc 1–6", "29/07": "Zc 7–14", "30/07": "Ed 7–10",
  "31/07": "Ne 1–4", "01/08": "Ne 5–7", "02/08": "Ne 8–10", "03/08": "Ne 11–13", "04/08": "Et 1–5",
  "05/08": "Et 6–10", "06/08": "Ml 1–4", "07/08": "Sl 1–5", "08/08": "Sl 6–10", "09/08": "Sl 11–15",
  "10/08": "Sl 16–20", "11/08": "Sl 21–25", "12/08": "Sl 26–30", "13/08": "Sl 31–35", "14/08": "Sl 36–40",
  "15/08": "Sl 41–45", "16/08": "Sl 46–50", "17/08": "Sl 52–55", "18/08": "Sl 56–60", "19/08": "Sl 61–65",
  "20/08": "Sl 66–70", "21/08": "Sl 71–75", "22/08": "Sl 76–80", "23/08": "Sl 81–85", "24/08": "Sl 86–89",
  "25/08": "Sl 91–95", "26/08": "Sl 96–100", "27/08": "Sl 101–105", "28/08": "Sl 106–110", "29/08": "Sl 111–115",
  "30/08": "Sl 116–118", "31/08": "Sl 119", "01/09": "Sl 120; Sl 121–125", "02/09": "Sl 126–130",
  "03/09": "Sl 131–135", "04/09": "Sl 136–140", "05/09": "Sl 141–145", "06/09": "Sl 146–150", "07/09": "Lc 1",
  "08/09": "Lc 2", "09/09": "Mt 1–2", "10/09": "Lc 3–4", "11/09": "Mt 3; Mc 1", "12/09": "Jo 1–2",
  "13/09": "Jo 3–4", "14/09": "Lc 5; Mt 4", "15/09": "Mc 2–3", "16/09": "Mc 4–5", "17/09": "Mt 5–6",
  "18/09": "Mt 7–8", "19/09": "Mt 9; Lc 6", "20/09": "Lc 7–8", "21/09": "Mt 10; Mc 6", "22/09": "Mc 7–8",
  "23/09": "Mt 11–12", "24/09": "Mt 13; Lc 9", "25/09": "Mc 9; Lc 10", "26/09": "Jo 5–6", "27/09": "Mt 14–15",
  "28/09": "Mc 10–11", "29/09": "Lc 11–12", "30/09": "Jo 7–8", "01/10": "Lc 13–14", "02/10": "Jo 9–10",
  "03/10": "Mt 16–17", "04/10": "Lc 15–16", "05/10": "Jo 11–12", "06/10": "Mt 18–19", "07/10": "Mc 12–13",
  "08/10": "Mt 20–21", "09/10": "Mt 22–23", "10/10": "Mt 24–25", "11/10": "Jo 13–14", "12/10": "Jo 15–16",
  "13/10": "Jo 17–18", "14/10": "Mt 26", "15/10": "Mt 27", "16/10": "Lc 22–23", "17/10": "Jo 19–20",
  "18/10": "Mt 28; Lc 24", "19/10": "Jo 21; At 1", "20/10": "At 2–3", "21/10": "At 4–5", "22/10": "At 6–7",
  "23/10": "At 8–9", "24/10": "At 10–11", "25/10": "At 12–13", "26/10": "At 14; Gl 1–2", "27/10": "Gl 3–5",
  "28/10": "Gl 6; At 15–16", "29/10": "At 17–18", "30/10": "At 19–20", "31/10": "At 21–22", "01/11": "At 23–24",
  "02/11": "At 25–26", "03/11": "At 27–28", "04/11": "Rm 1–2", "05/11": "Rm 3–4", "06/11": "Rm 5–6",
  "07/11": "Rm 7–8", "08/11": "Rm 9–10", "09/11": "Rm 11–12", "10/11": "Rm 13–14", "11/11": "Rm 15–16",
  "12/11": "1Co 1–2", "13/11": "1Co 3–4", "14/11": "1Co 5–6", "15/11": "1Co 7–8", "16/11": "1Co 9–10",
  "17/11": "1Co 11–12", "18/11": "1Co 13–14", "19/11": "1Co 15–16", "20/11": "2Co 1–2", "21/11": "2Co 3–4",
  "22/11": "2Co 5–6", "23/11": "2Co 7–8", "24/11": "2Co 9–10", "25/11": "2Co 11–12", "26/11": "2Co 13; Ef 1",
  "27/11": "Ef 2–3", "28/11": "Ef 4–5", "29/11": "Ef 6; Fp 1", "30/11": "Fp 2–3", "01/12": "Fp 4; Cl 1",
  "02/12": "Cl 2–3", "03/12": "Cl 4; Fm", "04/12": "Hb 1–2", "05/12": "Hb 3–4", "06/12": "Hb 5–6",
  "07/12": "Hb 7–8", "08/12": "Hb 9–10", "09/12": "Hb 11–12", "10/12": "Hb 13; Tg 1", "11/12": "Tg 2–3",
  "12/12": "Tg 4–5", "13/12": "1Pe 1–2", "14/12": "1Pe 3–4", "15/12": "1Pe 5; 2Pe 1", "16/12": "2Pe 2–3",
  "17/12": "1Jo 1–2", "18/12": "1Jo 3–4", "19/12": "1Jo 5; 2Jo", "20/12": "3Jo; Jd", "21/12": "Ap 1–2",
  "22/12": "Ap 3–4", "23/12": "Ap 5–6", "24/12": "Ap 7–8", "25/12": "Ap 9–10", "26/12": "Ap 11–12",
  "27/12": "Ap 13–14", "28/12": "Ap 15–16", "29/12": "Ap 17–18", "30/12": "Ap 19–20", "31/12": "Ap 21–22"
};

export const DAILY_VIDEOS: Record<string, VideoEntry[]> = {
  "01/01": [{ id: "b_-j75V6O44", title: "Gênesis 1 - O Deus da Criação", channel: "Rev. Hernandes Dias Lopes" }]
};

export const DAILY_WORSHIP: Record<string, WorshipEntry[]> = {
  "10/06": [{ title: "Ouve, Senhor (Oração de Ezequias)", artist: "Diante do Trono", id: "2aFj4CaUsHk" }]
};

export const PRIORITY_CHANNELS = [
  { name: "Rev. Hernandes Dias Lopes", keyword: "Hernandes Dias Lopes", icon: "🔥" },
  { name: "IP Pinheiros", keyword: "Igreja Presbiteriana de Pinheiros", icon: "⛪" },
  { name: "Rev. Augustus Nicodemus", keyword: "Augustus Nicodemus", icon: "📚" }
];

export const PASTORS = [
  "Josué Valandro Jr", "André Valadão", "Rodrigo Silva", "Hernandes Dias Lopes", "Tiago Brunet"
];
