
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { 
  BookOpen, 
  Video, 
  Heart, 
  MessageSquare, 
  Search, 
  Mic, 
  Music, 
  MapPin, 
  ChevronLeft, 
  ChevronRight, 
  CheckCircle,
  AlertCircle,
  Clock,
  Menu,
  X,
  Zap,
  Calendar as CalendarIcon,
  AlertTriangle
} from 'lucide-react';
import { 
  READING_PLAN_2026, 
  BIBLE_MAP, 
  BOOK_OVERVIEWS, 
  PRIORITY_CHANNELS, 
  DAILY_VIDEOS, 
  DAILY_WORSHIP, 
  PASTORS
} from './constants';
import { useReadingProgress } from './hooks/useReadingProgress';
import { ToolType } from './types';
import { fetchBibleText, parseReadingPlan } from './services/bibleService';
// Import mantido para referência futura, mas uso removido abaixo
import BibleTimeline from './components/BibleTimeline/BibleTimeline';

const App: React.FC = () => {
  const [dataNavegacao, setDataNavegacao] = useState<Date>(new Date());
  const [ferramentaAtual, setFerramentaAtual] = useState<ToolType>('texto');
  const [versaoAtual, setVersaoAtual] = useState<string>('almeida');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [bibleContent, setBibleContent] = useState<any[]>([]);
  
  const daysListRef = useRef<HTMLDivElement>(null);

  const [dayPart, setDayPart] = useState('');
  const [monthPart, setMonthPart] = useState('');
  const [yearPart, setYearPart] = useState('');

  const { leiturasConcluidas, toggleLeitura, getAtrasos, getPercentage } = useReadingProgress();

  const currentKey = useMemo(() => {
    const d = String(dataNavegacao.getDate()).padStart(2, '0');
    const m = String(dataNavegacao.getMonth() + 1).padStart(2, '0');
    return `${d}/${m}`;
  }, [dataNavegacao]);

  const currentReadingRaw = READING_PLAN_2026[currentKey];

  const currentReadingFull = useMemo(() => {
    if (!currentReadingRaw) return "Sem Leitura";
    return currentReadingRaw.split(';').map(part => {
      const p = part.trim();
      const espacoIdx = p.indexOf(' ');
      if (espacoIdx === -1) return p;
      const sigla = p.substring(0, espacoIdx);
      const resto = p.substring(espacoIdx);
      if (BIBLE_MAP[sigla]) return BIBLE_MAP[sigla].name + resto;
      return p;
    }).join('; ');
  }, [currentReadingRaw]);

  const atrasos = getAtrasos();
  const percentage = getPercentage();

  const progressColorClass = atrasos > 0 ? 'text-red-500' : 'text-emerald-500';
  const progressBarClass = atrasos > 0 ? 'bg-red-500' : 'bg-emerald-500';

  useEffect(() => {
    if (!isNaN(dataNavegacao.getTime())) {
      const d = String(dataNavegacao.getDate()).padStart(2, '0');
      const m = String(dataNavegacao.getMonth() + 1).padStart(2, '0');
      const y = String(dataNavegacao.getFullYear());
      
      if (dayPart !== d && !document.activeElement?.className.includes('day-input')) setDayPart(d);
      if (monthPart !== m && !document.activeElement?.className.includes('month-input')) setMonthPart(m);
      if (yearPart !== y && !document.activeElement?.className.includes('year-input')) setYearPart(y);
    }
  }, [dataNavegacao]);

  const scrollToActiveDay = () => {
    if (daysListRef.current) {
      const activeElement = daysListRef.current.querySelector('.active-day-item');
      if (activeElement) {
        activeElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  };

  useEffect(() => {
    scrollToActiveDay();
  }, [currentKey, isSidebarOpen]);

  useEffect(() => {
    if (ferramentaAtual === 'texto' && currentReadingRaw) {
      loadBibleText();
    }
  }, [currentReadingRaw, ferramentaAtual, versaoAtual]);

  async function loadBibleText() {
    setLoading(true);
    setError(null);
    try {
      const queries = parseReadingPlan(currentReadingRaw);
      const promises = queries.map(q => {
        const bookName = BIBLE_MAP[q.sigla]?.name || q.sigla;
        return fetchBibleText(`${bookName} ${q.cap}`, versaoAtual)
          .then(data => ({ ...data, meta: q, bookName }));
      });
      const results = await Promise.all(promises);
      setBibleContent(results);
    } catch (e) {
      setError("Erro ao carregar o texto bíblico.");
    } finally {
      setLoading(false);
    }
  }

  const handleMudarDia = (delta: number) => {
    const next = new Date(dataNavegacao);
    next.setDate(next.getDate() + delta);
    setDataNavegacao(next);
  };

  const handleIrParaAtraso = () => {
    const hoje = new Date();
    hoje.setHours(0,0,0,0);
    const iter = new Date(hoje.getFullYear(), 0, 1);
    while (iter < hoje) {
      const d = String(iter.getDate()).padStart(2, '0');
      const m = String(iter.getMonth() + 1).padStart(2, '0');
      const key = `${d}/${m}`;
      if (READING_PLAN_2026[key] && !leiturasConcluidas.includes(key)) {
        setDataNavegacao(new Date(iter));
        return;
      }
      iter.setDate(iter.getDate() + 1);
    }
  };

  const updateDateFromParts = (d: string, m: string, y: string) => {
    const day = parseInt(d);
    const month = parseInt(m);
    const year = parseInt(y);
    if (!isNaN(day) && day > 0 && day <= 31 && !isNaN(month) && month > 0 && month <= 12 && !isNaN(year) && year >= 2000 && year <= 2100) {
      const newDate = new Date(year, month - 1, day);
      if (!isNaN(newDate.getTime()) && newDate.getDate() === day) setDataNavegacao(newDate);
    }
  };

  const handleSegmentChange = (part: 'day' | 'month' | 'year', value: string) => {
    const cleaned = value.replace(/\D/g, '');
    if (part === 'day') {
      const v = cleaned.slice(0, 2);
      setDayPart(v);
      if (v.length > 0) updateDateFromParts(v, monthPart, yearPart);
    } else if (part === 'month') {
      const v = cleaned.slice(0, 2);
      setMonthPart(v);
      if (v.length > 0) updateDateFromParts(dayPart, v, yearPart);
    } else {
      const v = cleaned.slice(0, 4);
      setYearPart(v);
      if (v.length === 4) updateDateFromParts(dayPart, monthPart, v);
    }
  };

  const handlePickerChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    if (val) {
      const [year, month, day] = val.split('-').map(Number);
      setDataNavegacao(new Date(year, month - 1, day));
    }
  };

  const formattedWeekday = useMemo(() => {
    const wd = dataNavegacao.toLocaleDateString('pt-BR', { weekday: 'long' });
    const day = dataNavegacao.getDate();
    return (wd.charAt(0).toUpperCase() + wd.slice(1)) + ", " + String(day).padStart(2, '0');
  }, [dataNavegacao]);

  const formattedDateFull = useMemo(() => {
    const day = dataNavegacao.toLocaleDateString('pt-BR', { day: '2-digit' });
    const month = dataNavegacao.toLocaleDateString('pt-BR', { month: 'long' });
    return `${day} de ${month}`;
  }, [dataNavegacao]);

  const renderToolsContent = () => {
    if (loading) return (
      <div className="flex flex-col items-center justify-center h-full text-slate-400">
        <div className="w-10 h-10 border-4 border-slate-200 border-t-sky-400 rounded-full animate-spin mb-4"></div>
        <p className="font-medium">Sintonizando Escrituras...</p>
      </div>
    );

    if (error) return (
      <div className="flex flex-col items-center justify-center h-full p-8 text-center">
        <AlertCircle className="w-12 h-12 text-red-400 mb-4" />
        <p className="text-red-600 font-semibold">{error}</p>
        <button onClick={loadBibleText} className="mt-4 px-4 py-2 bg-red-50 text-red-600 rounded-lg font-medium hover:bg-red-100 transition-colors">Tentar Novamente</button>
      </div>
    );

    const currentQueries = parseReadingPlan(currentReadingRaw);
    const firstRef = currentQueries[0];
    const bookName = firstRef ? (BIBLE_MAP[firstRef.sigla]?.name || firstRef.sigla) : "";

    switch (ferramentaAtual) {
      case 'texto':
        return (
          <div className="pt-2 px-6 md:px-12 md:pt-2 lg:pt-4 overflow-y-auto h-full scroll-smooth pb-40 lg:pb-12">
            <div className="max-w-3xl mx-auto">
              
              {/* Timeline ocultada temporariamente conforme solicitação */}
              {/* <BibleTimeline currentQueries={currentQueries} /> */}

              {bibleContent.map((cap, idx) => {
                const isNewBook = cap.meta.cap === 1;
                const bookInfo = isNewBook ? (BOOK_OVERVIEWS[cap.meta.sigla] || BOOK_OVERVIEWS['Default']) : null;
                
                const bookNameText = cap.bookName;
                let specialPart = bookNameText.charAt(0);
                let restOfName = bookNameText.slice(1);

                // Lógica para livros numerados (ex: 1 Samuel)
                if (/^[1-3]\s+[A-Za-zÀ-ÿ]/.test(bookNameText)) {
                  specialPart = bookNameText.slice(0, 3); // "1 S"
                  restOfName = bookNameText.slice(3); // "amuel"
                }
                
                const isFirstChapter = idx === 0;

                return (
                  <div key={idx} className={`mb-2 ${isFirstChapter ? 'mt-2' : 'mt-4'}`}>
                    {bookInfo && (
                      <div className="bg-amber-50 border border-amber-200 rounded-2xl p-8 mb-10 shadow-sm mt-4">
                        <h2 className="font-serif text-3xl text-amber-900 mb-2">{bookInfo.title}</h2>
                        <p className="text-amber-800 mb-6 text-sm italic">{bookInfo.desc}</p>
                        {bookInfo.videoId && (
                          <div className="relative aspect-video rounded-xl overflow-hidden shadow-lg mb-8 bg-black">
                             <iframe className="absolute inset-0 w-full h-full" src={`https://www.youtube.com/embed/${bookInfo.videoId}`} frameBorder="0" allowFullScreen></iframe>
                          </div>
                        )}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
                          <div className="bg-white/50 p-4 rounded-xl border border-amber-100">
                            <span className="block text-[10px] uppercase font-bold text-amber-600 mb-1">Tema Principal</span>
                            <span className="text-slate-700 text-sm font-medium">{bookInfo.theme}</span>
                          </div>
                          <div className="bg-white/50 p-4 rounded-xl border border-amber-100">
                            <span className="block text-[10px] uppercase font-bold text-amber-600 mb-1">Versículo Chave</span>
                            <span className="text-slate-700 text-sm italic">{bookInfo.key}</span>
                          </div>
                        </div>
                        <div className="space-y-4">
                          <h4 className="text-sm font-bold text-amber-900 border-l-4 border-amber-400 pl-3">Contexto Histórico</h4>
                          <p className="text-slate-600 text-sm leading-relaxed">{bookInfo.context}</p>
                          <h4 className="text-sm font-bold text-amber-900 border-l-4 border-amber-400 pl-3">Cristo em {bookInfo.title}</h4>
                          <p className="text-slate-600 text-sm leading-relaxed">{bookInfo.christ}</p>
                        </div>
                      </div>
                    )}
                    
                    <div className={`flex justify-between items-start border-b border-slate-100 pb-0 mb-0.5 gap-2`}>
                       <h3 className="flex items-baseline gap-1 text-slate-800 overflow-visible pt-0">
                         {isFirstChapter ? (
                           <>
                             <span className="font-manuscript text-6xl text-amber-700 leading-[1] select-none inline-block px-1 overflow-visible whitespace-nowrap">{specialPart}</span>
                             <span className="font-serif text-3xl font-bold tracking-tight">{restOfName} {cap.meta.cap}</span>
                           </>
                         ) : (
                           <span className="font-serif text-xl font-bold tracking-tight text-slate-600">{cap.bookName} {cap.meta.cap}</span>
                         )}
                       </h3>
                       {isFirstChapter && (
                         <div className="text-[10px] uppercase tracking-widest text-slate-400 font-bold mt-1 self-start">
                           Versão: {versaoAtual === 'almeida' ? 'Almeida' : 'KJV'}
                         </div>
                       )}
                    </div>

                    <div className="font-serif text-lg leading-loose text-slate-700 space-y-2 text-justify">
                      {cap.verses.map((v: any, vIdx: number) => (
                        <span key={vIdx} className="inline mr-1">
                          <sup className="text-sky-400 font-sans font-bold mr-1 text-[10px]">{v.verse}</sup>
                          {v.text.trim()} 
                        </span>
                      ))}
                    </div>
                  </div>
                );
              })}

              <div className="mt-16 pt-12 border-t border-slate-100">
                <h4 className="flex items-center gap-2 text-lg font-bold text-slate-800 mb-6">
                  <Video className="w-5 h-5 text-red-500" /> Aprofundamento em Vídeo
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {(DAILY_VIDEOS[currentKey] || []).map((v, i) => (
                    <div key={i} className="bg-white border border-slate-100 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                      <div className="aspect-video bg-slate-900">
                        <iframe className="w-full h-full" src={`https://www.youtube.com/embed/${v.id}`} frameBorder="0" allowFullScreen></iframe>
                      </div>
                      <div className="p-4">
                        <h5 className="font-bold text-sm text-slate-800 line-clamp-2 mb-1">{v.title}</h5>
                        <span className="text-xs text-slate-500">{v.channel}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        );
      case 'video':
      case 'devocional':
      case 'pregacao':
        const keyword = ferramentaAtual === 'devocional' ? 'Devocional' : ferramentaAtual === 'pregacao' ? 'Pregação' : '';
        const list = ferramentaAtual === 'pregacao' ? PASTORS : PRIORITY_CHANNELS.map(c => c.name);
        return (
          <div className="p-8 h-full overflow-y-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 content-start pb-32 lg:pb-8">
            {list.map((name, i) => (
              <a key={i} href={`https://www.youtube.com/results?search_query=${keyword}+${name}+${bookName}+${firstRef?.cap}`} target="_blank" className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-lg hover:-translate-y-1 transition-all text-center flex flex-col items-center gap-4">
                <div className="w-16 h-16 bg-sky-50 text-sky-400 rounded-full flex items-center justify-center">
                  {ferramentaAtual === 'devocional' ? <Heart /> : ferramentaAtual === 'pregacao' ? <Mic /> : <Video />}
                </div>
                <div><h4 className="font-bold text-slate-800">{name}</h4><p className="text-sm text-slate-500 mt-1">{keyword} sobre {bookName}</p></div>
              </a>
            ))}
          </div>
        );
      case 'comentario':
        return (
          <div className="bg-[#fdfbf7] p-8 md:p-12 h-full overflow-y-auto pb-32 lg:pb-12">
            <div className="max-w-2xl mx-auto space-y-12 text-center">
               <h2 className="font-serif text-3xl text-slate-900 mb-2">Comentários Clássicos</h2>
               <div className="relative bg-white border border-stone-200 p-8 shadow-sm text-left">
                  <h4 className="font-bold text-slate-800 border-b pb-4 mb-4">Matthew Henry</h4>
                  <p className="font-serif text-slate-700 italic">"Ao lermos {bookName} {firstRef?.cap}, observamos a providência divina."</p>
               </div>
               <a href={`https://www.google.com/search?q=Comentario+Matthew+Henry+${bookName}+${firstRef?.cap}`} target="_blank" className="font-bold text-amber-800 underline">Ler no Google ↗</a>
            </div>
          </div>
        );
      case 'louvor':
        const worships = DAILY_WORSHIP[currentKey] || [];
        return (
          <div className="p-8 h-full overflow-y-auto space-y-12 pb-32 lg:pb-12 text-center">
            {worships.map((s, i) => (
              <div key={i} className="max-w-xl mx-auto bg-white border rounded-2xl overflow-hidden shadow-sm">
                <iframe className="w-full aspect-video" src={`https://www.youtube.com/embed/${s.id}`} frameBorder="0" allowFullScreen></iframe>
                <div className="p-6 text-center"><h4 className="font-bold text-slate-800">{s.title}</h4><p className="text-sky-500">{s.artist}</p></div>
              </div>
            ))}
          </div>
        );
      default:
        let searchUrl = `https://www.google.com/search?igu=1&q=Estudo+${bookName}+${firstRef?.cap}`;
        if (ferramentaAtual === 'pesquisa') searchUrl = `https://www.google.com/search?igu=1&q=Estudo+teologico+${bookName}+${firstRef?.cap}`;
        if (ferramentaAtual === 'mapa') searchUrl = `https://www.google.com/search?igu=1&tbm=isch&q=Mapa+Bíblico+${bookName}+${firstRef?.cap}`;
        return <div className="w-full h-full pb-32 lg:pb-0"><iframe src={searchUrl} className="w-full h-full border-none"></iframe></div>;
    }
  };

  const navItems = [
    { type: 'texto', label: 'Ler Texto', icon: <BookOpen />, category: 'Leitura & Vídeo' },
    { type: 'video', label: 'Vídeos Apoio', icon: <Video />, category: 'Leitura & Vídeo' },
    { type: 'devocional', label: 'Devocionais', icon: <Heart />, category: 'Aprofundamento' },
    { type: 'comentario', label: 'Comentários', icon: <MessageSquare />, category: 'Aprofundamento' },
    { type: 'pesquisa', label: 'Pesquisa', icon: <Search />, category: 'Aprofundamento' },
    { type: 'pregacao', label: 'Pregações', icon: <Mic />, category: 'Multimídia' },
    { type: 'louvor', label: 'Louvores', icon: <Music />, category: 'Multimídia' },
    { type: 'mapa', label: 'Mapas', icon: <MapPin />, category: 'Multimídia' },
  ];

  const bottomNavItems = [
    { type: 'texto', label: 'Texto', icon: <BookOpen size={20} /> },
    { type: 'pregacao', label: 'Pregações', icon: <Mic size={20} /> },
    { type: 'comentario', label: 'Comentários', icon: <MessageSquare size={20} /> },
    { type: 'louvor', label: 'Louvores', icon: <Music size={20} /> },
    { type: 'mapa', label: 'Mapas', icon: <MapPin size={20} /> },
  ];

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden text-slate-700">
      {isSidebarOpen && <div className="fixed inset-0 bg-slate-900/40 z-40 lg:hidden" onClick={() => setIsSidebarOpen(false)} />}
      <aside className={`fixed lg:static inset-y-0 left-0 w-[240px] bg-white border-r border-slate-200 flex flex-col z-50 transition-transform duration-300 lg:translate-x-0 ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="p-6 border-b border-slate-100">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3 text-sky-400"><div className="bg-sky-100 p-2 rounded-xl"><BookOpen className="w-6 h-6" /></div><span className="font-bold text-lg">Jornada 2026</span></div>
            <button className="lg:hidden p-2 text-slate-400" onClick={() => setIsSidebarOpen(false)}><X className="w-5 h-5" /></button>
          </div>
          <div className="space-y-3">
             <div className="flex items-center justify-between text-[10px] uppercase font-bold">
               <span className={atrasos > 0 ? "text-red-500" : "text-emerald-500"}>{atrasos > 0 ? 'EM ATRASO' : 'EM DIA'}</span>
               <span className={progressColorClass}>{percentage}% CONCLUÍDO</span>
             </div>
             <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden border border-slate-200"><div className={`h-full transition-all duration-700 ${progressBarClass}`} style={{ width: `${percentage}%` }} /></div>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto px-4 pt-1 pb-6 space-y-1" ref={daysListRef}>
          {Object.entries(READING_PLAN_2026).map(([key, ref]) => {
            const isActive = key === currentKey;
            const isRead = leiturasConcluidas.includes(key);
            const dateObj = new Date(2026, parseInt(key.split('/')[1])-1, parseInt(key.split('/')[0]));
            const isLate = !isRead && dateObj.getTime() < new Date().setHours(0,0,0,0);
            return (
              <button key={key} onClick={() => { setDataNavegacao(dateObj); setIsSidebarOpen(false); }} className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-left transition-all ${isActive ? 'bg-sky-50 text-sky-600 ring-1 ring-sky-100 shadow-sm active-day-item' : isLate ? 'bg-red-50 text-red-700 hover:bg-red-100' : 'hover:bg-slate-50 text-slate-600'}`}>
                <div className="flex items-center gap-3">
                  <span className={`text-[10px] font-bold ${isActive ? 'text-sky-400' : isLate ? 'text-red-400' : 'text-slate-500'}`}>{key}</span>
                  <span className={`text-sm font-medium ${isRead ? 'line-through text-slate-300 opacity-60' : ''}`}>{ref}</span>
                </div>
                {isRead ? <CheckCircle className="w-4 h-4 text-emerald-500" /> : isLate ? <Clock className="w-4 h-4 text-red-400" /> : null}
              </button>
            );
          })}
        </div>
      </aside>

      <main className="flex-1 flex flex-col min-w-0 relative">
        {/* Alerta de Leituras Atrasadas (TOPO - Ajustado para ser conciso e legível) */}
        {atrasos > 0 && (
          <div 
            onClick={handleIrParaAtraso}
            className="bg-red-600 px-4 py-2 flex items-center justify-center gap-2 animate-in slide-in-from-top duration-300 z-30 cursor-pointer hover:bg-red-700 transition-colors shadow-lg"
          >
            <AlertTriangle className="w-3.5 h-3.5 text-white shrink-0" />
            <span className="text-[13px] font-bold text-white whitespace-nowrap overflow-hidden text-ellipsis">
              Há {atrasos} {atrasos === 1 ? 'dia' : 'dias'} pendentes. Clique para ler.
            </span>
          </div>
        )}

        <header className="bg-white border-b border-slate-200 px-4 lg:px-6 py-2.5 lg:py-4 flex flex-col lg:flex-row lg:items-center justify-between gap-2 lg:gap-4 z-20 shadow-sm">
          <div className="flex flex-col lg:flex-row lg:items-center gap-2 lg:gap-6 min-w-0 w-full lg:w-auto">
            <div className="flex items-center gap-3 md:gap-4 min-w-0">
              <button className="lg:hidden p-2 -ml-2 text-slate-400" onClick={() => setIsSidebarOpen(true)}><Menu className="w-6 h-6" /></button>
              <div className="hidden sm:block border-r border-slate-100 pr-4 lg:pr-6 mr-2 text-left shrink-0">
                <div className="text-xs font-bold text-slate-800 mb-0.5">{formattedWeekday}</div>
                <div className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">{formattedDateFull}</div>
              </div>
              <h1 className="text-xl md:text-2xl font-bold text-slate-900 truncate flex-1">{currentReadingFull}</h1>
            </div>
            
            <button 
              onClick={() => toggleLeitura(currentKey)} 
              className={`flex items-center justify-center gap-2 px-5 py-1.5 lg:py-2.5 rounded-xl font-bold text-xs transition-all w-full lg:w-auto ${leiturasConcluidas.includes(currentKey) ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' : 'bg-sky-50 text-sky-600 border border-sky-200 hover:bg-sky-100'}`}
            >
              {leiturasConcluidas.includes(currentKey) ? <CheckCircle className="w-4 h-4" /> : <div className="w-4 h-4 rounded-full border-2 border-current" />}
              {leiturasConcluidas.includes(currentKey) ? 'Concluída' : 'Marcar Lido'}
            </button>
          </div>

          <div className="flex items-center gap-2 lg:gap-2 justify-between lg:justify-end w-full lg:w-auto overflow-x-auto no-scrollbar">
            <div className="bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 lg:py-2 flex items-center justify-center min-w-[80px]">
              <select className="bg-transparent text-[10px] md:text-xs font-bold text-sky-500 focus:outline-none cursor-pointer text-center w-full" value={versaoAtual} onChange={(e) => setVersaoAtual(e.target.value)}>
                <option value="almeida">JFA</option><option value="kjv">KJV</option>
              </select>
            </div>

            <div className="flex items-center bg-slate-50 border border-slate-200 rounded-xl p-0.5 shadow-sm min-w-max">
              <button onClick={() => handleMudarDia(-1)} className="p-1.5 text-slate-400 hover:text-sky-500 rounded-lg transition-all"><ChevronLeft className="w-4 h-4"/></button>
              <div className="flex items-center gap-0 px-1 select-none grow justify-center">
                <input type="text" value={dayPart} onFocus={(e) => e.target.select()} onChange={(e) => handleSegmentChange('day', e.target.value)} className="day-input bg-transparent text-[10px] md:text-xs font-bold text-slate-700 w-[2.2ch] text-center outline-none" />
                <span className="text-slate-300 font-bold mx-0.5">/</span>
                <input type="text" value={monthPart} onFocus={(e) => e.target.select()} onChange={(e) => handleSegmentChange('month', e.target.value)} className="month-input bg-transparent text-[10px] md:text-xs font-bold text-slate-700 w-[2.2ch] text-center outline-none" />
                <span className="text-slate-300 font-bold mx-0.5">/</span>
                <input type="text" value={yearPart} onFocus={(e) => e.target.select()} onChange={(e) => handleSegmentChange('year', e.target.value)} className="year-input bg-transparent text-[10px] md:text-xs font-bold text-slate-700 w-[4.2ch] text-center outline-none" />
              </div>
              <button onClick={() => handleMudarDia(1)} className="p-1.5 text-slate-400 hover:text-sky-500 rounded-lg transition-all"><ChevronRight className="w-4 h-4"/></button>
            </div>

            <div className="relative shrink-0">
              <button type="button" className="flex items-center justify-center p-2 bg-white border border-slate-200 text-slate-400 hover:text-sky-500 rounded-xl shadow-sm"><CalendarIcon className="w-4 h-4" /></button>
              <input type="date" className="absolute inset-0 opacity-0 cursor-pointer w-full h-full z-10" onChange={handlePickerChange} />
            </div>

            <button onClick={() => setDataNavegacao(new Date())} className="flex items-center justify-center gap-2 px-4 py-2 bg-white border border-amber-300 text-amber-500 rounded-xl text-[10px] md:text-xs font-bold hover:bg-amber-50 transition-colors shadow-sm shrink-0">
              <Zap className="w-3.5 h-3.5 fill-current" /> <span className="hidden sm:inline">Hoje</span>
            </button>
          </div>
        </header>

        <div className="flex-1 flex overflow-hidden">
          <nav className="hidden md:flex flex-col w-[200px] border-r border-slate-100 bg-white/50 backdrop-blur-sm p-4 overflow-y-auto">
            {['Leitura & Vídeo', 'Aprofundamento', 'Multimídia'].map(cat => (
              <div key={cat} className="mb-6">
                <span className="block text-[9px] uppercase font-bold text-slate-400 tracking-[0.2em] mb-3 ml-2">{cat}</span>
                <div className="space-y-1">
                  {navItems.filter(i => i.category === cat).map(item => (
                    <button key={item.type} onClick={() => setFerramentaAtual(item.type as ToolType)} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${ferramentaAtual === item.type ? 'bg-white shadow-sm ring-1 ring-slate-200 text-sky-500' : 'text-slate-500 hover:text-slate-800 hover:translate-x-1'}`}>
                      <span className={ferramentaAtual === item.type ? 'text-sky-400' : 'text-slate-400'}>{React.cloneElement(item.icon as React.ReactElement, { size: 18 })}</span>{item.label}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </nav>
          <div className="flex-1 overflow-hidden relative">{renderToolsContent()}</div>
        </div>

        {/* Mobile Bottom Navigation - Elegante e Harmônica */}
        <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-xl border-t border-slate-200 px-2 py-2 flex items-center justify-around z-40 shadow-[0_-4px_16px_rgba(0,0,0,0.04)] pb-[calc(0.5rem+env(safe-area-inset-bottom))]">
          {bottomNavItems.map((item) => {
            const isActive = ferramentaAtual === item.type;
            return (
              <button 
                key={item.type} 
                onClick={() => setFerramentaAtual(item.type as ToolType)}
                className={`flex flex-col items-center justify-center gap-1.5 flex-1 px-1 py-1 rounded-xl transition-all duration-300 ${isActive ? 'text-sky-500' : 'text-slate-400 active:scale-95'}`}
              >
                <div className={`transition-transform duration-300 ${isActive ? 'scale-110' : ''}`}>
                  {React.cloneElement(item.icon as React.ReactElement, { 
                    strokeWidth: isActive ? 2.5 : 2,
                    className: isActive ? 'drop-shadow-[0_0_8px_rgba(14,165,233,0.3)]' : ''
                  })}
                </div>
                <span className={`text-[9px] font-bold uppercase tracking-wider transition-all ${isActive ? 'opacity-100' : 'opacity-70 font-medium'}`}>
                  {item.label}
                </span>
                {isActive && (
                  <div className="absolute top-0 w-8 h-1 bg-sky-500 rounded-full animate-in fade-in slide-in-from-top-1 duration-300" />
                )}
              </button>
            );
          })}
        </nav>
      </main>
      <style>{`
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>
    </div>
  );
};

export default App;
