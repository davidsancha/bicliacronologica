
export interface Verse {
  book_id: string;
  book_name: string;
  chapter: number;
  verse: number;
  text: string;
}

export interface BibleApiResponse {
  reference: string;
  verses: Verse[];
  text: string;
  translation_id: string;
  translation_name: string;
  translation_note: string;
}

export interface BookOverview {
  title: string;
  desc: string;
  context: string;
  theme: string;
  key: string;
  christ: string;
  videoId: string | null;
}

export interface BibleMapEntry {
  name: string;
  theme: string;
}

export interface VideoEntry {
  id: string;
  title: string;
  channel: string;
}

export interface WorshipEntry {
  title: string;
  artist: string;
  id: string;
}

export type ToolType = 'texto' | 'video' | 'devocional' | 'comentario' | 'pesquisa' | 'pregacao' | 'louvor' | 'mapa';

export interface ReadingQuery {
  sigla: string;
  cap: number;
}

export interface BiblicalEra {
  id: string;
  title: string;
  dispensation: string;
  description: string;
  books: string[];
  color: string;
  icon: string;
  year: string;
}
